import axios from "axios";
import type { CropPrice, Crop, SavePricePayload } from "../types";

const BASE_URL = "http://localhost:8081";

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: { "Content-Type": "application/json" },
});

export const farmerApi = {
  getPrices: () => api.get<CropPrice[]>("/public/farmerDashboard"),
};

export const cropApi = {
  getAll: () => api.get<Crop[]>("/public/allCrops"),
};

export const adminApi = {
  savePrice: (payload: SavePricePayload) => api.post("/admin/prices", payload),
};

export default api;
